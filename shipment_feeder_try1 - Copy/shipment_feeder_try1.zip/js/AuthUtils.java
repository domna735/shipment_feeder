package hkapps.shipment_feeder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class AuthUtils {
    public static boolean checkAuthentication(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("emailadr") == null) {
            response.sendRedirect(request.getContextPath() + "/toLogin.html");
            return false;
        }
        return true;
    }
}
