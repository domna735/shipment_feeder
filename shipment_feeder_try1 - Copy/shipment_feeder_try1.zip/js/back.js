window.onload=function() {
    document.getElementById("backButton").addEventListener("click", function() {
        history.go(-1);
    });
}
