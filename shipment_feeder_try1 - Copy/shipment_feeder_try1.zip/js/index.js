self.focus();
self.resizeTo(850,700);
self.moveTo(0,0);
