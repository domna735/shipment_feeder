window.onload=function(){
    nextpage('ip_DefPage.jsp',false);
}
